#' @title separate individual alignments according to their lengths.
#' @description extract individual alignment(s) with aligned length longer than a given threshold.
#' @details extract longer alignment(s) and output into a new fold.
#' The input alignment should be in fasta format.
#' @param obj A variable of DNA alignment read in R.
#' @param alignment_name is the specified file name of the input DNA alignment.
#' @param Len a user's specified number above which alignment with a length is to be put into
#' a new folder.
#' @param short_alignments Logic values TRUE or FALSE. If TRUE, output the short alignments to the
#' designated folder too.
#' @importFrom magrittr %>%
#' @return DNA alignments with length longer or shorter than a given threshold (parameter "Len"), respectively.
#' @examples
#' library(magrittr)
#' obj_names <- dir(system.file("extdata", package = "alignmentFilter"), full.names = TRUE)
#' obj = lapply(obj_names, readLines)
#' alignmentLength(obj = obj[[1]], alignment_name = basename(obj_names[1]), Len = 100)
#' unlink(x = c("long_alignments", "short_alignments"), recursive = TRUE)
#' # run single object.
#' mapply(FUN = alignmentLength, obj, alignment_name = basename(obj_names), Len = 100)
#' unlink(x = c("long_alignments", "short_alignments"), recursive = TRUE)
#' #run multiple objects in batch.
#' # if run in parallel using multiple threads, set as below:
#' library(parallel)
#' cl = makeCluster(2)
#' clusterMap(cl, fun = alignmentLength, obj, alignment_name = obj_names, Len = 100)
#' stopCluster(cl)
#' unlink(x = c("long_alignments", "short_alignments"), recursive = TRUE)
#' @export

alignmentLength <- function (obj, alignment_name, Len = 200, short_alignments = F)
{
  taxa_indexes <- grep(pattern = ">", x = obj)
  seq1_begin <- taxa_indexes[1] + 1
  seq1_end <- taxa_indexes[2] - 1
  length_alignment <- nchar(obj[seq1_begin:seq1_end]) %>% sum
  if (length_alignment >= Len)
  {
    dir.create("long_alignments/", showWarnings = F)
    file.copy(from = alignment_name, to = paste0("long_alignments/", alignment_name))
  }
  else
  {
    if (short_alignments == T)
    {
      dir.create("short_alignments/", showWarnings = F)
      file.copy(from = alignment_name, to = paste0("short_alignments/", alignment_name))
    }
  }
}
