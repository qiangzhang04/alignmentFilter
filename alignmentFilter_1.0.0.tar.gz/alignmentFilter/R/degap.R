#' @title remove gappy sites (columns).
#' @description The gappy columns having gaps equal or over than a given threshold are removed.
#' @details If the datatype is codon and if any site (column) in a codon has a proportion of gaps
#' equal or over the specified threshold, the codon as a whole would be pruned. The function
#' would check if alignment is of a length of multiple of three but not check premature stop codon
#' if the datatype selected as "codon". If p_flankgap or p set to zero and there is not any gap,
#' no site (column) would be deleted. If there is any sequence completely composed of gaps,
#' it would be assumed to contain none flank gaps as unable to be regularly matched in identifying flank
#' gaps using our regular expression. The program checks and removes the flank (terminal) gaps first
#' if check_flank_gaps is set to true, and after that all other gaps are checked according to the cutoff
#' set by p.
#' @param obj A variable of DNA alignment in fasta format.
#' @param alignment_name A given name by the user for naming output file.
#' @param datatype A character string, either "DNA" or "codon".
#' @param p A number in proportion from 0 to 1, specifying the cutoff value (threshold),
#' equal or over which sites (or codons) are to be removed.
#' @param p_flankgap A number in proportion from 0 to 1, specifying the cutoff value,
#' equal or over which the terminal sites (or codons) at both ends are to be removed.
#' @param check_flank_gaps A logic deciding whether check and treat the terminal gaps
#' at both ends firstly.
#' @importFrom magrittr %>%
#' @return degapped DNA alignments.
#' @examples
#' library(magrittr)
#' obj_names <- dir(system.file("extdata",package = "alignmentFilter"), full.names = TRUE)
#' obj <- lapply(X = obj_names, FUN = readLines)
#' degap(obj = obj[[1]], alignment_name = basename(obj_names[1]), p = 0.6)
#' # run single object.
#' unlink(x = "degaps", recursive = TRUE)
#' mapply(FUN = degap, obj, alignment_name = basename(obj_names), p = 0.6)
#' unlink(x = "degaps", recursive = TRUE)
#' # if run in parallel using multiple threads, set as below:
#' library(parallel)
#' cl = makeCluster(2)
#' clusterMap(cl, fun = degap, obj, alignment_name = basename(obj_names), p = 0.6)
#' stopCluster(cl)
#' unlink(x = "degaps", recursive = TRUE)
#' @export

degap <- function(obj, alignment_name, datatype = "DNA",
                        p = 0.5, p_flankgap = 0.5, check_flank_gaps = T)
{
  # dir.create(path = "degaps/", showWarnings = F)
  all_taxa <- grep(pattern = "^>", x = obj, value = T)
  begin_seq_index <- grep(pattern = "^>", x = obj) + 1
  all_seq <- NULL

  # extract all the taxa and corresponding sequences. The matrix sequences should be in fasta format, but it works whether in a line or in multiple lines of the sequences
  v = 1
  repeat
  {
    if (v < length(begin_seq_index))
    {
      seq_v <- obj[begin_seq_index[v] : (begin_seq_index[v + 1] - 2)] %>% paste0(collapse = "")
      all_seq <- append(all_seq, seq_v)
    }
    else if (v == length(begin_seq_index))
    {
      seq_v <- obj[begin_seq_index[v] : length(obj)] %>% paste0(collapse = "")
      all_seq <- append(all_seq, seq_v)
    }
    else
      break
    v = v + 1
  }

  ##########################################################################
  # check if the alignment contains sequences identical in length
  if (all_seq %>% nchar %>% unique %>% length != 1)
  {
    print("error: the matrix has unequal sites")
  }
  #identify and delete the beginning regions with excessive gaps
  Prop_taxa_begin_withgap <- -1
  Prop_taxa_end_withgap <- -1
  if (check_flank_gaps == T)
  {
    begin_deletion_list <- gregexpr(pattern = "^[-?\\N]{1,}\\w", text = all_seq)
    begin_del_length <- NULL
    for (k in 1:length(begin_deletion_list))
    {
      begin_del_length_k <- begin_deletion_list[[k]] %>% attr(which = "match.length")
      begin_del_length <- c(begin_del_length, begin_del_length_k)
    }
    sorted_begin_del_length <- begin_del_length %>% sort(decreasing = T)
    taxa_begin_withgap <- all_taxa[which(begin_del_length > 0)]
    Prop_taxa_begin_withgap <- (taxa_begin_withgap %>% length)/(all_taxa %>% length)
    if (Prop_taxa_begin_withgap >= p_flankgap)
    {
      if (p_flankgap == 0)
      {
        trim_gapLen_at_beginning <-  sorted_begin_del_length[1] - 1
      }
      if (p_flankgap > 0)
      {
        trim_gapLen_at_beginning_cut <- (sorted_begin_del_length %>% length() * p_flankgap) %>% floor()
        trim_gapLen_at_beginning <- sorted_begin_del_length[trim_gapLen_at_beginning_cut] - 1

      }
      matrix_length <- nchar(all_seq[1])
      if (datatype == "codon")
      {
        if (trim_gapLen_at_beginning %% 3 != 0)
        {
          if (trim_gapLen_at_beginning %% 3 == 1)
          {
            trim_gapLen_at_beginning <- trim_gapLen_at_beginning + 2
          }
          if (trim_gapLen_at_beginning %% 3 == 2)
          {
            trim_gapLen_at_beginning <- trim_gapLen_at_beginning + 1
          }
        }
      }

      if (trim_gapLen_at_beginning > 0)
      {
        trim_length_at_beginning <- trim_gapLen_at_beginning + 1
        all_seq <- all_seq %>% substr(trim_length_at_beginning, matrix_length)
      }
    }

    #########################################################################################
    #identify and delete the end regions with excessive gaps
    endgap_list <- gregexpr(pattern = "(\\w|\\*|!)[-?\\N]{1,}$", text = all_seq)
    end_del_length <- NULL
    for (kk in 1:length(endgap_list))
    {
      end_del_length_k <- endgap_list [[kk]] %>% attr(which = "match.length")
      end_del_length <- c(end_del_length, end_del_length_k)
    }
    sorted_end_del_length <- end_del_length %>% sort(decreasing = T)
    taxa_end_withgap <- all_taxa[which(end_del_length > 0)]
    Prop_taxa_end_withgap <- (taxa_end_withgap %>% length)/(all_taxa %>% length)
    if (Prop_taxa_end_withgap >= p_flankgap)
    {
      if (p_flankgap == 0)
      {
        trim_gapLen_at_end <- sorted_end_del_length[1] - 1
      }
      if (p_flankgap > 0)
      {
        trim_gapLen_at_end_cut <- (sorted_end_del_length %>% length() * p_flankgap) %>% ceiling()
        trim_gapLen_at_end <- sorted_end_del_length[trim_gapLen_at_end_cut] - 1
      }
      matrix_length <- nchar(all_seq[1])
      if (datatype == "codon")
      {
        if (trim_gapLen_at_end %% 3 != 0)
        {
          if (trim_gapLen_at_end %% 3 == 1)
          {
            trim_gapLen_at_end <- trim_gapLen_at_end + 2
          }
          else if (trim_gapLen_at_end %% 3 == 2)
          {
            trim_gapLen_at_end <- trim_gapLen_at_end + 1
          }
        }
      }
      if (trim_gapLen_at_end > 0)
      {
        trim_pos_at_end <- matrix_length - trim_gapLen_at_end
        all_seq <- all_seq %>% substr(1, trim_pos_at_end)
      }
    }
    matrix_degaps <- all_taxa %>% paste(all_seq, sep = "\n")
  }
  ############################################################################
  # identify which site(s) is gappy sites that should be deleted
  gap_sites <- NULL
  length_taxa <- length(all_taxa)
  for (i in 1:nchar(all_seq[1]))
  {
    gap_ratio <- substring(all_seq, i, i) %>%
      grep(pattern = "A|T|G|C", value = T, ignore.case = T, invert = T) %>%
      length/length_taxa
    if (gap_ratio  >= p & p != 0)
    {
      gap_sites <- c(gap_sites, i)
    }
    else if (gap_ratio != 0 & p == 0)
    {
      gap_sites <- c(gap_sites, i)
    }
  }
  # If there is any gappy site identified, then delete it

  if (gap_sites %>% length > 0)
  {
    ## If data type is DNA (i.e. none coding sequence), just delete the identified gappy site(s)
    if (datatype == "DNA")
    {
      all_seq_split <- strsplit(all_seq, split = "")
      all_seq_degaps <- NULL
      for (j in 1:length(all_seq_split))
      {
        all_seq_degaps <- all_seq_split[[j]][-gap_sites] %>% paste0(collapse = "") %>%
          append(x = all_seq_degaps)
      }
      matrix_degaps <- all_taxa %>% paste(all_seq_degaps, sep = "\n")
      # writeLines(matrix_degaps, con = paste0("degaps/", "degaps_", obj))
    }
    ## if the data is coding sequence, then the whole codon triplet-site indexes in original sequence(s) are given below if the codon contains at least one site that is identified as gappy site
    if (datatype == "codon")
    {
      # if the aligned sequence length is not a multiple of three, it is not a complete codon sequence and stop as an error
      # stopifnot(all(((all_seq %>% nchar) %% 3) == 0) == T)
      # summarize the codon triplet-sites that need to be deleted
      del_codon_sites <- NULL
      for (kkk in 1:length(gap_sites))
      {
        if (gap_sites[kkk] %% 3 == 0)
        {
          del_codon_sites <- c(gap_sites[kkk], gap_sites[kkk] - 1, gap_sites[kkk] - 2) %>%
            append(x = del_codon_sites)
        }

        else if (gap_sites[kkk] %% 3 == 1)
        {
          del_codon_sites <- c(gap_sites[kkk], gap_sites[kkk] + 1, gap_sites[kkk] + 2) %>%
            append(x = del_codon_sites)
        }
        else if (gap_sites[kkk] %% 3 == 2)
        {
          del_codon_sites <- c(gap_sites[kkk], gap_sites[kkk] - 1, gap_sites[kkk] + 1) %>%
            append(x = del_codon_sites)
        }
      }
      # exclude the duplicated gappy sites produced above
      del_codon_sites <- del_codon_sites %>% unique()
      # delete codon columns if there is any codon that needs to be deleted
      if (del_codon_sites %>% length > 0)
      {
        all_seq_split <- strsplit(all_seq, split = "")
        all_seq_degaps <- NULL
        for (m in 1:length(all_seq_split))
        {
          all_seq_degaps <- all_seq_split[[m]][-del_codon_sites] %>%
            paste0(collapse = "") %>% append(x = all_seq_degaps)
        }
        matrix_degaps <- all_taxa %>% paste(all_seq_degaps, sep = "\n")
        # writeLines(matrix_degaps, con = paste0("degaps/", "degaps_", obj))
      }
    }
  }
  if (gap_sites %>% length > 0 | Prop_taxa_end_withgap >= p_flankgap | Prop_taxa_begin_withgap >= p_flankgap)
  {
    dir.create(path = "degaps/", showWarnings = FALSE)
    writeLines(matrix_degaps, con = paste0("degaps/", alignment_name, ".fas"))
  }
}
