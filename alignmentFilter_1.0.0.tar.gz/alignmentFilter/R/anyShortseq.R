#' @title delete short sequences in alignment.
#' @description short sequences in alignment shorter than any of the two thresholds specified by
#' either Len or LenP are deleted.
#' @details Alignment should be in fasta format and can contain the four nucleotide symbols "ATGC"
#' in both lower and upper cases. Degenerate nucleotide symbols, e.g. N, are not be counted in length
#' calculation.
#' @param obj A variable of DNA alignment in fasta format read in R.
#' @param alignment_name The name of the DNA alignment (obj).
#' @param Len A number specifying cutoff below which sequences are to be deleted from alignment.
#' @param LenP A number in proportion from 0 to 1, also specifying cutoff below which
#' sequences are to be deleted.
#' @importFrom magrittr %>%
#' @importFrom utils write.csv
#' @return Two objects including reduced alignment with short sequences removed,
#' and the document of the information about which alignment and short sequence were treated.
#' @examples
#' obj_names <- dir(system.file("extdata", package = "alignmentFilter"), full.names = TRUE)
#' obj = lapply(obj_names, readLines)
#' anyShortseq(obj = obj[[1]], alignment_name = basename(obj_names[1]), Len = 100)
#' # run single object
#' unlink(x = c("short_seq_information", "data_without_shortseq"), recursive = TRUE)
#' mapply(FUN = anyShortseq, obj, alignment_name = basename(obj_names), Len = 100)
#' #run multiple objects in batch.
#' unlink(x = c("short_seq_information", "data_without_shortseq"), recursive = TRUE)
#' # if run in parallel using multiple threads, set as below:
#' library(parallel)
#' cl = makeCluster(2)
#' clusterMap(cl, fun = anyShortseq, obj, alignment_name = basename(obj_names), Len = 100)
#' stopCluster(cl)
#' unlink(x = c("short_seq_information", "data_without_shortseq"), recursive = TRUE)
#' @export

anyShortseq <- function(obj, alignment_name, Len = 50, LenP = 0.1)
{
  short_nucStr <- NULL
  manyNs <- NULL
  # extract all the taxa and corresponding sequences. The matrix sequences should be in fasta format, but it works whether in a line or in multiple lines of the sequences
  all_taxa_indexes <- grep(pattern = "^>", x = obj)
  all_taxa <-  obj[all_taxa_indexes]
  begin_seq_index <- grep(pattern = "^>", x = obj) + 1
  all_seq <- NULL

  v = 1
  repeat
  {
    if (v < length(begin_seq_index))
    {
      seq_v <- obj[begin_seq_index[v] : (begin_seq_index[v + 1] - 2)] %>% paste0(collapse = "")
      all_seq <- append(all_seq, seq_v)
    }
    else if (v == length(begin_seq_index))
    {
      seq_v <- obj[begin_seq_index[v] : length(obj)] %>% paste0(collapse = "")
      all_seq <- append(all_seq, seq_v)
    }
    else
      break
    v = v + 1
  }

  #assess which sequence(s) is short
  all_seq_split <- strsplit(all_seq, split = "")
  Len_matrix <- all_seq[1] %>% nchar
  shortseq_indexes <- NULL
  for (i in 1:length(all_seq_split))
  {
    nucString_sites <- all_seq_split[[i]] %in% c("A", "T", "G", "C", "a", "t", "g", "c")
    Len_nucString <- all_seq_split[[i]][nucString_sites] %>% length()
    LenP_nucstring <- Len_nucString/ Len_matrix
    Ns_sites <- all_seq_split[[i]] %in% c("N", "n")
    len_Ns <- all_seq_split[[i]][Ns_sites] %>% length()
    if (Len_nucString < Len | LenP_nucstring < LenP)
    {
      short_nucStr_i <- data.frame(alignment_name, all_taxa[i], Len_nucString)
      short_nucStr <- rbind(short_nucStr, short_nucStr_i)
      shortseq_indexes <- c(shortseq_indexes, i)
    }
  }

  # output information about which data has which short sequence(s) and output the new data without any short sequence
  if (short_nucStr$Len_nucString %>% length > 0)
  {
    dir.create("short_seq_information/", showWarnings = F)
    dir.create("data_without_shortseq/", showWarnings = F)
    write.csv(short_nucStr, file = paste0("short_seq_information/", alignment_name,
                                          "_short_seq_information.csv"))

    seqs_remained <- all_seq[-shortseq_indexes]
    taxa_remained <- all_taxa[-shortseq_indexes]
    paste(taxa_remained, seqs_remained, sep = "\n") %>%
      writeLines(con = paste0("data_without_shortseq/", "rmShortseq_", alignment_name, ".fas"))
  }
}
