#' @title mask divergent segments in alignment.
#' @description To identify and mask divergent segments in alignment is based on
#' raw similarity scores and sliding window, with group(s) of segments which
#' has low similarity to any segments of the main group masked with "N".
#' @details Ambiguously-aligned or divergent segments contained in alignment likely affects
#' many downstream analyses. These functions in the package alignmentFilter including maskSegment
#' is designed for treating DNA alignment (both non-coding and coding sequences). The default settings,
#' particularly with higher sc can work well enough even for divergent sequences from across high
#' taxonomic units, e.g. angiosperm-scale phylogenetic reconstruction, as if the taxa are densely sampled.
#' maskSegment assesses all input alignments and output them all even if none segments are masked.
#' The information about which alignments and taxa and which segments are masked
#  are recorded in the output information files.
#' Note if DNA type is codon, the window width and step must be set with numbers that are multiple of 3.
#' @param obj A variable of DNA alignment read in R.
#' @param file_name The name of the DNA alignment.
#' @param type A character string either "DNA" or "codon".
#' @param sc A number denoting similarity cutoff that controls the stringency, below which
#' the segments with divergence are to be masked. Higher sc would mask more segments.
#' @param window_width A number controlling the width of sliding window. Larger value could
#' speed up but may fail to identify short divergent segment.
#' @param window_step A number controlling the step size of sliding window. Larger value could
#' speed up but may decrease power of identifying (short) divergent segments. Note this value
#' should at least be lower than the window width, or some sites (columns) would be skipped, not
#' included in any sliding window for evaluation.
#' @param checkcase A logic value TRUE or FALSE. If TRUE, the nucleotides in lower case are rewritten
#' in upper case.
#' @importFrom magrittr %>%
#' @importFrom utils write.csv
#' @return Two sorts of objects including (masked) alignments and files about information of
#' position(s) of masked segments in alignment and the corresponding taxa names.
#' @examples
#' file_name = dir(system.file("extdata", package = "alignmentFilter"), full.names = TRUE)
#' obj = lapply(X = file_name, FUN = readLines)
#' maskSegment(obj = obj[[1]], file_name = file_name[1], sc = 0.6)
#'  # run single object
#' unlink(x = c("mask_alignment", "mask_information"), recursive = TRUE)
#' mapply(FUN = maskSegment, obj = obj, file_name = file_name, sc = 0.6)
#' #run multiple objects in batch.
#' unlink(x = c("mask_alignment", "mask_information"), recursive = TRUE)
#' # if run in parallel using multiple threads, set as below:
#' library(parallel)
#' cl = makeCluster(2)
#' clusterMap(cl, fun = maskSegment, obj, file_name = file_name, sc = 0.6)
#' stopCluster(cl)
#' unlink(x = c("mask_alignment", "mask_information"), recursive = TRUE)
#' @export

maskSegment <- function(obj, file_name, type = "DNA",
                        sc = 0.5, window_width = 15, window_step = 3, checkcase = F)
{
  dir.create("mask_alignment/", showWarnings = F)
  dir.create("mask_information/", showWarnings = F)
  all_taxa <- grep(pattern = "^>", x = obj, value = T)
  begin_seq_index <- grep(pattern = "^>", x = obj) + 1
  all_seq <- NULL

  # extract all the taxa and corresponding sequences. The matrix sequences should be in fasta format, but it works whether in a line or in multiple lines of the sequences
  v = 1
  repeat
  {
    if (v < length(begin_seq_index))
    {
      seq_v <- obj[begin_seq_index[v] : (begin_seq_index[v + 1] - 2)] %>% paste0(collapse = "")
      all_seq <- append(all_seq, seq_v)
    }
    else if (v == length(begin_seq_index))
    {
      seq_v <- obj[begin_seq_index[v] : length(obj)] %>% paste0(collapse = "")
      all_seq <- append(all_seq, seq_v)
    }
    else
      break
    v = v + 1
  }
  # if there is any nucleotide in lower case (a,t,g,c), transform into upper case uniformly to avoid mistakes for calculating similarity scores
  if (checkcase == T)
  {
    lower_case_indexes <- grep(pattern = "a|g|t|c", x = all_seq)
    if (lower_case_indexes %>% length > 0)
    {
      for (v in 1:length(lower_case_indexes))
      {
        all_seq[lower_case_indexes] <- all_seq[lower_case_indexes] %>% toupper()
      }
    }
  }

  # divide the alignment into windows of segments in both conditions of type DNA or codon sequences

  if (type == "DNA")
  {
    all_windowed_segments <- NULL
    window_begin_site_Pos <- NULL
    m = 1
    mm = 1
    while (m <= nchar(all_seq[1]) - (window_width -1))
    {
      windowed_codons <- substring(all_seq, m, m +  (window_width -1))
      all_windowed_segments[[mm]] <- windowed_codons
      window_begin_site_Pos <- c(window_begin_site_Pos, m)
      m = m + window_step
      mm = mm + 1
    }
  }

  if (type == "codon")
  {
    # if the aligned sequence length is not a multiple of three, it is not a complete codon sequence and stop as an error
    # real_codons <- all((all_seq %>% nchar %% 3  == 0) == T)
    # if (real_codons == F)
    # {
    #   stop("alignment length is not a multiple of 3, maybe not codon sequence")
    # }
    # if (window_width %% 3 != 0 | window_step %% 3 != 0)
    # {
    #   stop("both window width and step must be set to multiple of 3 for codon sequence")
    # }
    # divide codon sequences into windows of segments
    all_windowed_segments <- NULL
    window_begin_site_Pos <- NULL
    # decide all windows and the beginning positions of each of the windows
    ##Attention: if multiple objects (entries) included in a list by none sequential indexes (such as 1, 3, 5..without any formal names),
    ### the list will automatically added the skipped number of entries with NULL
    m = 1
    mm = 1
    while (m <= nchar(all_seq[1]) - (window_width -1))
    {
      windowed_codons <- substring(all_seq, m, m +  (window_width -1))
      all_windowed_segments[[mm]] <- windowed_codons
      window_begin_site_Pos <- c(window_begin_site_Pos, m)
      m = m + window_step
      mm = mm + 1
    }
  }

  # identify the windows that need mask
  mask_window_taxaIndex <- NULL
  for (k in 1:length(all_windowed_segments))
  {
    length_ATGC <-
      all_windowed_segments[[k]] %>% strsplit(split = "") %>%
      lapply(FUN = grep, pattern = "A|T|G|C") %>% lapply(FUN = length)
    include_taxa_indexes <- which(length_ATGC >= 3)
    # if the window of segments comprises no definite nucleotide, then skip (do nothing). Otherwise, do next step.
    if (include_taxa_indexes %>% length > 1)
    {
      # set initial values, which would alter along with the following loops
      groups <- NULL
      remained_taxa_pool <- include_taxa_indexes
      # m denotes how many tentative groups (with a beginning value 1) the window of segments would be divided into in the first round of grouping
      m = 1
      repeat
      {
        # transfer_mmm denotes the index(es) of the segments that should be transferred into group m.
        # transfer_mmm is assigned with a initial value 1 and would likely be appended more segment index(es).
        # And all the final transfer_mmm values (segment indexes) would be transferred into groups[[m]] as they have ss values equal or high than sc
        # mm (double) denotes the first segment in remained_taxa_pool, and mmm (triple m) denotes iterator from 2 to the last segment in remained_taxa_pool
        transfer_mmm <- 1
        groups[[m]] <- remained_taxa_pool[1]
        for (mm in 1)
        {
          for (mmm in 2:length(remained_taxa_pool))
          {
            # caculate pairwise similarity score
            count_indentity <- 0
            compare_times <- 0
            for (n in 1:nchar(all_windowed_segments[[k]][mm]))
            {
              seq1_n <- substring(text = all_windowed_segments[[k]][remained_taxa_pool[mm]], n, n)
              seq2_n <- substring(text = all_windowed_segments[[k]][remained_taxa_pool[mmm]], n, n)
              if (seq1_n %in% c("A", "T", "G", "C", "a", "t", "g", "c") &
                  seq2_n %in% c("A", "T", "G", "C", "a", "t", "g", "c"))
              {
                if (seq1_n == seq2_n)
                {
                  count_indentity <- count_indentity + 1
                  compare_times <- compare_times + 1
                }
                else if (seq1_n != seq2_n)
                {
                  compare_times <- compare_times + 1
                }
              }
            }
            # if no pair of definite nucleotides included in a pair of compared segments, then ss would be NaN
            if (compare_times >= 3)
            {
              raw_similarity_score <- count_indentity/compare_times
            }
            else
            {
              raw_similarity_score <- NaN
            }


            if (is.element(raw_similarity_score, NaN) == F)
            {
              if (raw_similarity_score >= sc)
              {
                groups[[m]] <- c(groups[[m]], remained_taxa_pool[mmm])
                transfer_mmm <- c(transfer_mmm, mmm)
              }
            }
          }
        }
        # along with running of above loops, the remained_taxa_pool decreases.
        # If there is zero or only one segment in remained_taxa_pool, break the loop directly or after assigning the last segment into a new groups.
        # Otherwise if there is more than one segment in remained_taxa_pool, go on the loops to divide them into groups.
        remained_taxa_pool <- remained_taxa_pool[-transfer_mmm]
        if (remained_taxa_pool %>% length == 0)
        {
          break
        }
        else if (remained_taxa_pool %>% length == 1)
        {
          groups[m + 1] <- remained_taxa_pool
          break
        }
        m = m + 1
      }
      # if the initial cluster groups are more than one, then evaluate whether they can be merged
      ##(any paired sequences from distinct groups have raw similarity values bigger than the given cutoff_sim)
      # through recalculating the similarity scores of all paired sequences from every two groups
      # add a mirror group which will help the looped group fixed but mirror group can merge if meet with specific condition
      ##and the next (last) step to overwrite (or not) depending on mirror group
      mirror_groups <- groups
      if (groups %>% length > 1)
      {
        for (g in 1:length(groups))
        {
          for (gg in (g + 1):length(groups))
          {
            for (q in 2:length(groups[[g]]))
            {
              loop_q <- 1
              for (qq in 1:length(groups[[gg]]))
              {
                count_indentity <- 0
                compare_times <- 0
                if (groups[[g]] %>% length >= 2)
                {
                  for (n in 1:nchar(all_windowed_segments[[k]][groups[[g]][q]]))
                  {
                    seq1_n <- substring(text = all_windowed_segments[[k]][groups[[g]][q]], n, n)
                    seq2_n <- substring(text = all_windowed_segments[[k]][groups[[gg]][qq]], n, n)

                    if (seq1_n %in% c("A", "T", "G", "C", "a", "t", "g", "c") &
                        seq2_n %in% c("A", "T", "G", "C", "a", "t", "g", "c"))
                    {
                      if (seq1_n == seq2_n)
                      {
                        count_indentity <- count_indentity + 1
                        compare_times <- compare_times + 1
                      }
                      else if (seq1_n != seq2_n)
                      {
                        compare_times <- compare_times + 1
                      }
                    }
                  }
                }
                if (compare_times >= 3)
                {
                  raw_similarity_score <- count_indentity/compare_times
                }
                else
                {
                  raw_similarity_score <- NaN
                }

                if (is.element(raw_similarity_score, NaN) == F)
                {
                  if (raw_similarity_score >= sc)
                  {
                    mirror_groups[[gg]] <- c(mirror_groups[[gg]], mirror_groups[[g]]) %>% unique
                    loop_q <- loop_q + 1
                    break
                  }
                }
              }
              if (loop_q > 1)
              {
                break
              }
            }
          }
          # if iterator running to the last groups, end the loop
          if (g + 1 == length(groups))
          {
            break
          }
        }

        # test whether the mirror groups can be merged or not.
        # If two mirror groups have a same taxa index, merge them into one.
        for (r in 1:length(mirror_groups))
        {
          mirror_groups[[r]] = mirror_groups[[r]] %>% unique
        }

        for (r in 1:length(mirror_groups))
        {
          for (rr in (r + 1):length(mirror_groups))
          {
            if (intersect(mirror_groups[[r]], mirror_groups[[rr]]) %>% length > 0)
            {
              mirror_groups[[rr]] <- c(mirror_groups[[rr]], mirror_groups[[r]]) %>% unique
            }
          }
          if (r + 1 >= length(mirror_groups))
          {
            break
          }
        }
        # mirror_major_group_index denotes the group with largest number of taxa
        # In occasion, more than one groups/mirror groups have the equal largest number of taxa. So that choose the first largest mirror group as the major group.
        mirror_major_group_index <-
          which(sapply(mirror_groups, length) == max(sapply(mirror_groups, length)))
        mirror_major_group_index <- mirror_major_group_index[1]
        mirror_major_group_taxa_index <- mirror_groups[mirror_major_group_index] %>% unlist
        mirror_minor_groups_taxa_index <-  setdiff(include_taxa_indexes, mirror_major_group_taxa_index)

        #summarize the information about window and taxa that need to mask
        if (mirror_minor_groups_taxa_index %>% length > 0)
        {
          mask_window_taxaIndex_k <-
            data.frame(window_begin_site_Pos[k], mirror_minor_groups_taxa_index %>% paste0(collapse = ","))
          mask_window_taxaIndex <- rbind(mask_window_taxaIndex, mask_window_taxaIndex_k)
        }
      }
    }
  }
  # If there is any need to be masked
  if (mask_window_taxaIndex[,2] %>% length > 0)
  {
    for (s in 1:length(mask_window_taxaIndex[,1]))
    {
      del_taxa_index_s <- mask_window_taxaIndex[,2][s] %>% strsplit(split = ",") %>% unlist %>% as.numeric()
      del_window_s <- mask_window_taxaIndex[,1][s]

      substring(all_seq[del_taxa_index_s],
                del_window_s, del_window_s + window_width -1)  <-
        substring(all_seq[del_taxa_index_s], del_window_s, del_window_s + window_width -1) %>%
        gsub(pattern = "A|T|G|C", replacement = "N", ignore.case = T)
    }
    writeLines(paste(all_taxa, all_seq, sep = "\n"),
               con = paste0("mask_alignment/", "mask_alignment_", basename(file_name)))
  }

  if (mask_window_taxaIndex[,1] %>% length > 0)
  {
    names(mask_window_taxaIndex) <- c("mask_window_begin_site", "mask_taxa_indexes")
    write.csv(mask_window_taxaIndex,
              file = paste0("mask_information/", basename(file_name) ,"_mask_window_taxa.csv"))
  }
}


