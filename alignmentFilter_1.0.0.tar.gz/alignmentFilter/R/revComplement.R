#' @title identify and adjust possible reverse complement sequences in alignment.
#' @description The common (phylogenetic) pipelines may bring reverse complementary homologous sequences
#' in alignment. This function is to identify and adjust possible fewer sequences that are homologous
#' but in reverse direction (minus) to other majority of sequences in forward direction (plus).
#' @details This function is based on the program blast, whose output file is used as an input file for
#' running this function to identify whether there exists any reverse complementary homologous sequence.
#' If there is any reverse complementary homologous sequence contained, the sequence in the same
#' direction and less numbers are to be reverse complemented regardless of whether they are really plus
#' or minus strand if they are protein coding genes.
#' Note: if unusual symbols such as "!" contained, they will be deleted directly from
#' the output sequences.
#' @param obj_blast A variable of the blastout file read in R.
#' @param obj A variable of set of DNA sequences read in R.
#' @param filename The name of the input DNA sequence file.
#' @importFrom magrittr %>%
#' @importFrom Biostrings readDNAStringSet
#' @importFrom Biostrings reverseComplement
#' @importFrom Biostrings writeXStringSet
#' @return Alignment with reverse complementary sequences adjusted.
#' @examples
#' library(magrittr)
#' library(Biostrings)
#' blastoutFilename <- system.file("extdata", package = "alignmentFilter") %>%
#' dir(pattern = "results_OG", full.names = TRUE)
#' obj_blast <- lapply(X = blastoutFilename, readLines)
#' filename <- system.file("extdata" ,package = "alignmentFilter") %>%
#'  dir(pattern = "_revcom.fasta$", full.names = TRUE)
#' obj <- lapply(X = filename, readDNAStringSet)
#' revComplement(obj_blast = obj_blast[[1]], obj[[1]], filename = filename[1])
#' #run single object.
#' unlink(x = "reverse_complement_data", recursive = TRUE)
#' mapply(FUN = revComplement, obj_blast = obj_blast, obj = obj, filename = filename)
#' unlink(x = "reverse_complement_data", recursive = TRUE)
#' #run multiple objects in batch.
#' # if run in parallel using multiple threads, set as below:
#' library(parallel)
#' cl = makeCluster(2)
#' clusterMap(cl, fun = revComplement, obj_blast = obj_blast, obj = obj, filename = filename)
#' stopCluster(cl)
#' unlink(x = "reverse_complement_data", recursive = TRUE)
#' @export

revComplement <- function(obj_blast, obj, filename)
{
  taxa_names <-  grep(pattern = ">", x = obj_blast, value = T)
  direction_status <- NULL
  for (k in 1 : length(taxa_names))
  {
    taxa_name_index <- grep(pattern = taxa_names[k], x = obj_blast)
    direction_status_k <-
      grep(pattern = "Strand=", x = obj_blast[taxa_name_index:length(obj_blast)], value = T)
    direction_status_k <- direction_status_k[1]
    direction_status <- append(direction_status, direction_status_k)
  }
  rev_complement_index <- grep(pattern = "Plus/Minus", x = direction_status, fixed = T)
  # if there is any reverse complementary sequence included
  if (rev_complement_index %>% length > 0)
  {
    dir.create("reverse_complement_data/", showWarnings = F)
    double_plus <- grep(pattern = "Plus/Plus", x = direction_status)
    plus_minus <- grep(pattern = "Plus/Minus", x = direction_status)
    rev_complement_taxa <- taxa_names[rev_complement_index]
    # read the sequences of the corresponding gene that contain at least one minus sequence and reverse complement it
    # extract all the taxa and corresponding sequences. The matrix sequences should be in fasta format, but it works whether in a line or in multiple lines of the sequences
    if (double_plus %>% length >= plus_minus %>% length)
    {
      for (j in 1:length(rev_complement_index))
      {
        revcom_seq_index <- grep(pattern = rev_complement_taxa[j] %>%
                                   gsub(pattern = "> ", replacement = ""), x = obj %>%
                                   names())
        obj[revcom_seq_index] <- obj[revcom_seq_index] %>% reverseComplement()
      }
      writeXStringSet(x = obj, filepath = paste0("reverse_complement_data/", basename(filename),
                                                     "_rev_complement.fasta"))
    }

    if (double_plus %>% length < plus_minus %>% length)
    {
      rev_complement_index <- grep(pattern = "Plus/Plus", x = direction_status, fixed = T)
      rev_complement_taxa <- taxa_names[rev_complement_index]
      for (j in 1:length(rev_complement_index))
      {
        revcom_seq_index <- grep(pattern = rev_complement_taxa[j] %>%
                                   gsub(pattern = "> ", replacement = ""), x = obj %>%
                                   names())
        obj[revcom_seq_index] <- obj[revcom_seq_index] %>%
          reverseComplement()
      }
      writeXStringSet(x = obj, filepath = paste0("reverse_complement_data/", basename(filename),
                                                     "_rev_complement.fasta"))
    }
  }
}
