#' @title Separate individual alignments (of nucleotide or amino acid sequences) according to their lengths.
#' @description Extract individual alignment(s) with aligned length longer than a given threshold.
#' @details Copy longer alignment(s) to a new fold. The input alignment should be in FASTA format.
#' @param obj A variable of nucleotide sequence alignment read in R.
#' @param alignment_name The specified file name of the input DNA alignment.
#' @param Len A user's specified number above which alignment with a length is to be put into a new folder.
#' @param short_alignments Logic values TRUE or FALSE. If TRUE, output the short alignments to a new folder.
#' @importFrom magrittr %>%
#' @return Alignments with length longer or shorter than a given threshold (parameter "Len"), respectively.
#' @examples
#' library(magrittr)
#' # The following is a data set built in this package alignmentFilter.
#' obj_names <- dir(system.file("extdata", package = "alignmentFilter"), full.names = TRUE) %>%
#' grep(pattern = "fasta$", value = TRUE)
#' obj = lapply(obj_names, readLines)
#' # But if your data is saved in such as a folder named mydata under disc D, you can set the R
#' # working directory to the folder and read your data like this if the names of data files end
#' # with suffix .fasta:
#' # setwd("D:\\mydata")
#' # obj_names <- list.files(pattern = ".fasta$")
#' # obj <- lapply(obj_names, readLines)
#' # Run single object. Pay attention to that the class of obj is list, so single operation target
#' # should be retrieved using two pairs of brackets, as shown below.
#' alignmentLength(obj = obj[[1]], alignment_name = basename(obj_names[1]), Len = 100)
#' #Note: the following function unlink will delete the folders along with the contained files.
#' # Do not run this function except you want.
#' unlink(x = c("long_alignments", "short_alignments"), recursive = TRUE)
#' #run multiple objects in batch.
#' mapply(FUN = alignmentLength, obj, alignment_name = basename(obj_names), Len = 100)
#' #Note: the following function unlink will delete the folders along with the contained files.
#' # Do not run this function except you want.
#' unlink(x = c("long_alignments", "short_alignments"), recursive = TRUE)
#' #If run in parallel using multiple threads (e.g. two threads), set as below:
#' library(parallel)
#' cl = makeCluster(2)
#' clusterMap(cl, fun = alignmentLength, obj, alignment_name = obj_names, Len = 100)
#' stopCluster(cl)
#' #Note: the following function unlink will delete the folders along with the contained files.
#' #Do not run this function except you want.
#' unlink(x = c("long_alignments", "short_alignments"), recursive = TRUE)
#' @export

alignmentLength <- function (obj, alignment_name, Len = 200, short_alignments = F)
{
  taxa_indexes <- grep(pattern = ">", x = obj)
  seq1_begin <- taxa_indexes[1] + 1
  seq1_end <- taxa_indexes[2] - 1
  length_alignment <- nchar(obj[seq1_begin:seq1_end]) %>% sum
  if (length_alignment >= Len)
  {
    dir.create("long_alignments/", showWarnings = F)
    file.copy(from = alignment_name, to = paste0("long_alignments/", alignment_name))
  }
  else
  {
    if (short_alignments == T)
    {
      dir.create("short_alignments/", showWarnings = F)
      file.copy(from = alignment_name, to = paste0("short_alignments/", alignment_name))
    }
  }
}
